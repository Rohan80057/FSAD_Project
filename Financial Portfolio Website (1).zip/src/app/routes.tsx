import { createBrowserRouter } from 'react-router';
import { Root } from './Root';
import { Home } from './pages/Home';
import { Portfolio } from './pages/Portfolio';
import { Markets } from './pages/Markets';
import { About } from './pages/About';
import { Goals } from './pages/Goals';
import { Transactions } from './pages/Transactions';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { Profile } from './pages/Profile';
import { NotFound } from './pages/NotFound';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: 'portfolio', Component: Portfolio },
      { path: 'markets', Component: Markets },
      { path: 'goals', Component: Goals },
      { path: 'transactions', Component: Transactions },
      { path: 'profile', Component: Profile },
      { path: 'about', Component: About },
      { path: 'login', Component: Login },
      { path: 'signup', Component: Signup },
      { path: '*', Component: NotFound },
    ],
  },
]);