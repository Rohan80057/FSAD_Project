import { TrendingUp, TrendingDown, DollarSign, Percent, ArrowUpRight, PieChart, Activity, AlertCircle } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RePieChart, Pie, Cell, Legend } from 'recharts';
import { Link } from 'react-router';
import { AnimatedBackground } from '../components/AnimatedBackground';

const portfolioData = [
  { month: 'Jan', value: 245000 },
  { month: 'Feb', value: 258000 },
  { month: 'Mar', value: 252000 },
  { month: 'Apr', value: 268000 },
  { month: 'May', value: 285000 },
  { month: 'Jun', value: 293000 },
  { month: 'Jul', value: 287000 },
  { month: 'Aug', value: 305000 },
  { month: 'Sep', value: 318000 },
  { month: 'Oct', value: 312000 },
  { month: 'Nov', value: 328000 },
  { month: 'Dec', value: 342500 },
];

// Asset Allocation Data
const assetAllocation = [
  { name: 'Equity', value: 246300, percentage: 71.9, color: '#0a0a0a' },
  { name: 'Debt', value: 68500, percentage: 20.0, color: '#404040' },
  { name: 'Cash', value: 20700, percentage: 6.0, color: '#737373' },
  { name: 'Alternatives', value: 7000, percentage: 2.1, color: '#a3a3a3' },
];

const holdings = [
  { symbol: 'AAPL', name: 'Apple Inc.', shares: 450, avgPrice: 145.23, currentPrice: 178.52, allocation: 28.4, type: 'Equity' },
  { symbol: 'MSFT', name: 'Microsoft Corporation', shares: 320, avgPrice: 285.67, currentPrice: 338.11, allocation: 22.1, type: 'Equity' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', shares: 180, avgPrice: 125.34, currentPrice: 142.89, allocation: 18.7, type: 'Equity' },
  { symbol: 'AMZN', name: 'Amazon.com Inc.', shares: 210, avgPrice: 128.45, currentPrice: 156.78, allocation: 15.2, type: 'Equity' },
  { symbol: 'NVDA', name: 'NVIDIA Corporation', shares: 95, avgPrice: 420.12, currentPrice: 512.34, allocation: 10.8, type: 'Equity' },
  { symbol: 'TSLA', name: 'Tesla Inc.', shares: 65, avgPrice: 198.45, currentPrice: 178.23, allocation: 4.8, type: 'Equity' },
];

// Risk Metrics
const riskMetrics = [
  { label: 'Volatility (σ)', value: '18.4%', status: 'medium' },
  { label: 'Beta (β)', value: '1.12', status: 'medium' },
  { label: 'Max Drawdown', value: '-12.3%', status: 'low' },
  { label: 'Sharpe Ratio', value: '1.85', status: 'high' },
];

// Income Tracking
const incomeData = [
  { source: 'Dividends', amount: 4250, ytd: 12750, type: 'Equity' },
  { source: 'Interest', amount: 850, ytd: 2550, type: 'Debt' },
  { source: 'Coupons', amount: 320, ytd: 960, type: 'Debt' },
];

export function Portfolio() {
  const totalValue = 342500;
  const totalGain = 97500;
  const gainPercent = 39.8;
  const cagr = 15.6;
  const xirr = 16.2;
  const idleCash = 20700;

  return (
    <div className="min-h-screen pt-32 pb-20 px-6 lg:px-12 relative">
      <AnimatedBackground intensity="low" />
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="mb-16 flex items-center justify-between">
          <div>
            <h1 className="text-6xl tracking-tight mb-4">Portfolio Overview</h1>
            <p className="text-xl text-muted-foreground">Comprehensive asset management and analysis</p>
          </div>
          <Link
            to="/goals"
            className="px-6 py-3 border border-border hover:bg-muted transition-colors"
          >
            View Goals
          </Link>
        </div>

        {/* Portfolio Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          <div className="border border-border p-8 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground tracking-wide">TOTAL VALUE</span>
              <DollarSign size={20} className="text-muted-foreground" />
            </div>
            <div className="text-4xl tracking-tight">${totalValue.toLocaleString()}</div>
            <div className="flex items-center text-sm text-success">
              <TrendingUp size={16} className="mr-1" />
              <span>+12.4% this month</span>
            </div>
          </div>

          <div className="border border-border p-8 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground tracking-wide">TOTAL GAIN</span>
              <ArrowUpRight size={20} className="text-muted-foreground" />
            </div>
            <div className="text-4xl tracking-tight text-success">${totalGain.toLocaleString()}</div>
            <div className="flex items-center text-sm text-success">
              <TrendingUp size={16} className="mr-1" />
              <span>+{gainPercent}% all time</span>
            </div>
          </div>

          <div className="border border-border p-8 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground tracking-wide">CAGR / XIRR</span>
              <Percent size={20} className="text-muted-foreground" />
            </div>
            <div className="text-4xl tracking-tight">{cagr}%</div>
            <div className="text-sm text-muted-foreground">XIRR: {xirr}%</div>
          </div>

          <div className="border border-border p-8 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground tracking-wide">IDLE CASH</span>
              <Activity size={20} className="text-muted-foreground" />
            </div>
            <div className="text-4xl tracking-tight">${idleCash.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Available to invest</div>
          </div>
        </div>

        {/* Asset Allocation & Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {/* Asset Allocation Pie Chart */}
          <div className="border border-border p-8">
            <h2 className="text-2xl tracking-tight mb-8 flex items-center">
              <PieChart size={24} className="mr-2" />
              Asset Allocation
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <RePieChart>
                <Pie
                  data={assetAllocation}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percentage }) => `${name}: ${percentage}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {assetAllocation.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </RePieChart>
            </ResponsiveContainer>
            <div className="mt-6 space-y-3">
              {assetAllocation.map((item) => (
                <div key={item.name} className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 mr-2" style={{ backgroundColor: item.color }} />
                    <span>{item.name}</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-muted-foreground">{item.percentage}%</span>
                    <span className="font-medium">${item.value.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Performance Chart */}
          <div className="border border-border p-8">
            <h2 className="text-2xl tracking-tight mb-8">12-Month Performance</h2>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={portfolioData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" style={{ fontSize: '12px' }} />
                <YAxis stroke="var(--muted-foreground)" style={{ fontSize: '12px' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--card)',
                    border: '1px solid var(--border)',
                    borderRadius: '0',
                    color: 'var(--foreground)',
                  }}
                />
                <Area type="monotone" dataKey="value" stroke="#22c55e" fillOpacity={1} fill="url(#colorValue)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk Metrics */}
        <div className="border border-border p-8 mb-16">
          <h2 className="text-2xl tracking-tight mb-8 flex items-center">
            <AlertCircle size={24} className="mr-2" />
            Risk Metrics
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {riskMetrics.map((metric) => (
              <div key={metric.label} className="space-y-2">
                <div className="text-sm text-muted-foreground">{metric.label}</div>
                <div className="text-3xl tracking-tight">{metric.value}</div>
                <div className={`text-xs px-2 py-1 inline-block border ${
                  metric.status === 'high' ? 'border-success text-success' :
                  metric.status === 'medium' ? 'border-muted-foreground text-muted-foreground' :
                  'border-destructive text-destructive'
                }`}>
                  {metric.status.toUpperCase()}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Holdings Table */}
        <div className="border border-border mb-16">
          <div className="p-8 border-b border-border flex items-center justify-between">
            <h2 className="text-2xl tracking-tight">Current Holdings</h2>
            <Link to="/transactions" className="text-sm text-muted-foreground hover:text-foreground">
              View All Transactions →
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left p-6 text-sm tracking-wide text-muted-foreground">SYMBOL</th>
                  <th className="text-left p-6 text-sm tracking-wide text-muted-foreground">NAME</th>
                  <th className="text-right p-6 text-sm tracking-wide text-muted-foreground">SHARES</th>
                  <th className="text-right p-6 text-sm tracking-wide text-muted-foreground">AVG PRICE</th>
                  <th className="text-right p-6 text-sm tracking-wide text-muted-foreground">CURRENT</th>
                  <th className="text-right p-6 text-sm tracking-wide text-muted-foreground">GAIN/LOSS</th>
                  <th className="text-right p-6 text-sm tracking-wide text-muted-foreground">MARKET VALUE</th>
                </tr>
              </thead>
              <tbody>
                {holdings.map((holding) => {
                  const gainLoss = ((holding.currentPrice - holding.avgPrice) / holding.avgPrice) * 100;
                  const isPositive = gainLoss >= 0;
                  const marketValue = holding.shares * holding.currentPrice;
                  
                  return (
                    <tr key={holding.symbol} className="border-b border-border hover:bg-muted/30 transition-colors">
                      <td className="p-6 tracking-tight font-medium">{holding.symbol}</td>
                      <td className="p-6 text-muted-foreground">{holding.name}</td>
                      <td className="p-6 text-right">{holding.shares}</td>
                      <td className="p-6 text-right text-muted-foreground">${holding.avgPrice.toFixed(2)}</td>
                      <td className="p-6 text-right font-medium">${holding.currentPrice.toFixed(2)}</td>
                      <td className="p-6 text-right">
                        <div className={`flex items-center justify-end ${isPositive ? 'text-success' : 'text-destructive'}`}>
                          {isPositive ? <TrendingUp size={16} className="mr-1" /> : <TrendingDown size={16} className="mr-1" />}
                          <span>{isPositive ? '+' : ''}{gainLoss.toFixed(2)}%</span>
                        </div>
                      </td>
                      <td className="p-6 text-right font-medium">${marketValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Income Tracking */}
        <div className="border border-border">
          <div className="p-8 border-b border-border">
            <h2 className="text-2xl tracking-tight">Income Tracking</h2>
            <p className="text-sm text-muted-foreground mt-2">Dividends, interest, and coupon payments</p>
          </div>
          <div className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {incomeData.map((income) => (
                <div key={income.source} className="space-y-3">
                  <div className="text-sm text-muted-foreground">{income.source}</div>
                  <div className="text-3xl tracking-tight">${income.amount.toLocaleString()}</div>
                  <div className="text-sm">
                    <span className="text-muted-foreground">YTD: </span>
                    <span className="text-success">${income.ytd.toLocaleString()}</span>
                  </div>
                  <div className="text-xs px-2 py-1 inline-block border border-border">{income.type}</div>
                </div>
              ))}
            </div>
            <div className="mt-8 pt-8 border-t border-border">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Total Monthly Income</span>
                <span className="text-2xl tracking-tight text-success">$5,420</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}