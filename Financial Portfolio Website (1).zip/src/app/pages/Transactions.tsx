import { ArrowDownLeft, ArrowUpRight, DollarSign, Filter, Search, Calendar } from 'lucide-react';
import { useState } from 'react';

const transactions = [
  {
    id: 1,
    date: '2026-02-12',
    time: '14:35',
    type: 'buy',
    symbol: 'NVDA',
    name: 'NVIDIA Corporation',
    shares: 25,
    price: 512.34,
    total: 12808.50,
    fees: 5.00,
    category: 'Equity',
  },
  {
    id: 2,
    date: '2026-02-12',
    time: '09:15',
    type: 'dividend',
    symbol: 'AAPL',
    name: 'Apple Inc.',
    shares: 450,
    price: 0,
    total: 450.00,
    fees: 0,
    category: 'Income',
  },
  {
    id: 3,
    date: '2026-02-08',
    time: '11:22',
    type: 'sell',
    symbol: 'TSLA',
    name: 'Tesla Inc.',
    shares: 15,
    price: 185.67,
    total: 2785.05,
    fees: 5.00,
    category: 'Equity',
  },
  {
    id: 4,
    date: '2026-02-05',
    time: '10:00',
    type: 'buy',
    symbol: 'AAPL',
    name: 'Apple Inc.',
    shares: 50,
    price: 176.23,
    total: 8811.50,
    fees: 5.00,
    category: 'Equity',
  },
  {
    id: 5,
    date: '2026-02-01',
    time: '13:45',
    type: 'buy',
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    shares: 30,
    price: 335.45,
    total: 10063.50,
    fees: 5.00,
    category: 'Equity',
  },
  {
    id: 6,
    date: '2026-01-28',
    time: '15:30',
    type: 'interest',
    symbol: 'CASH',
    name: 'Savings Interest',
    shares: 0,
    price: 0,
    total: 125.00,
    fees: 0,
    category: 'Income',
  },
  {
    id: 7,
    date: '2026-01-15',
    time: '09:00',
    type: 'fee',
    symbol: '-',
    name: 'Account Maintenance',
    shares: 0,
    price: 0,
    total: 25.00,
    fees: 25.00,
    category: 'Fee',
  },
  {
    id: 8,
    date: '2026-01-10',
    time: '14:20',
    type: 'dividend',
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    shares: 320,
    price: 0,
    total: 384.00,
    fees: 0,
    category: 'Income',
  },
];

const sipSchedule = [
  {
    id: 1,
    fund: 'Vanguard Total Stock Market',
    amount: 1000,
    frequency: 'Monthly',
    nextDate: '2026-03-01',
    status: 'active',
  },
  {
    id: 2,
    fund: 'Fidelity 500 Index Fund',
    amount: 750,
    frequency: 'Monthly',
    nextDate: '2026-03-01',
    status: 'active',
  },
  {
    id: 3,
    fund: 'Vanguard Bond Index Fund',
    amount: 500,
    frequency: 'Quarterly',
    nextDate: '2026-04-01',
    status: 'active',
  },
];

export function Transactions() {
  const [filterType, setFilterType] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTransactions = transactions.filter((tx) => {
    const matchesType = filterType === 'all' || tx.type === filterType;
    const matchesSearch =
      searchTerm === '' ||
      tx.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'buy':
        return <ArrowDownLeft size={20} className="text-destructive" />;
      case 'sell':
        return <ArrowUpRight size={20} className="text-success" />;
      case 'dividend':
      case 'interest':
        return <DollarSign size={20} className="text-success" />;
      case 'fee':
        return <DollarSign size={20} className="text-destructive" />;
      default:
        return <DollarSign size={20} />;
    }
  };

  const getTypeLabel = (type: string) => {
    return type.charAt(0).toUpperCase() + type.slice(1);
  };

  const totalInflows = transactions
    .filter((tx) => ['sell', 'dividend', 'interest'].includes(tx.type))
    .reduce((sum, tx) => sum + tx.total, 0);

  const totalOutflows = transactions
    .filter((tx) => ['buy', 'fee'].includes(tx.type))
    .reduce((sum, tx) => sum + tx.total, 0);

  return (
    <div className="min-h-screen pt-32 pb-20 px-6 lg:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-16">
          <h1 className="text-6xl tracking-tight mb-4">Transactions</h1>
          <p className="text-xl text-muted-foreground">Complete transaction history and SIP management</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <div className="border border-border p-8 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground tracking-wide">TOTAL INFLOWS</span>
              <ArrowUpRight size={20} className="text-success" />
            </div>
            <div className="text-4xl tracking-tight text-success">${totalInflows.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Sales & income</div>
          </div>

          <div className="border border-border p-8 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground tracking-wide">TOTAL OUTFLOWS</span>
              <ArrowDownLeft size={20} className="text-destructive" />
            </div>
            <div className="text-4xl tracking-tight text-destructive">${totalOutflows.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Purchases & fees</div>
          </div>

          <div className="border border-border p-8 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground tracking-wide">NET FLOW</span>
              <DollarSign size={20} className="text-muted-foreground" />
            </div>
            <div className={`text-4xl tracking-tight ${totalInflows - totalOutflows >= 0 ? 'text-success' : 'text-destructive'}`}>
              ${Math.abs(totalInflows - totalOutflows).toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">This period</div>
          </div>
        </div>

        {/* SIP Management */}
        <div className="border border-border mb-16">
          <div className="p-8 border-b border-border">
            <h2 className="text-2xl tracking-tight mb-2">SIP Management</h2>
            <p className="text-sm text-muted-foreground">Systematic Investment Plans - Auto investments</p>
          </div>
          <div className="divide-y divide-border">
            {sipSchedule.map((sip) => (
              <div key={sip.id} className="p-8 hover:bg-muted/30 transition-colors">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg tracking-tight mb-2">{sip.fund}</h3>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <span>{sip.frequency}</span>
                      <span>•</span>
                      <span className="flex items-center">
                        <Calendar size={14} className="mr-1" />
                        Next: {new Date(sip.nextDate).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl tracking-tight mb-2">${sip.amount.toLocaleString()}</div>
                    <span className="text-xs px-3 py-1 border border-success text-success">
                      {sip.status.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="p-8 bg-muted/30 border-t border-border">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Monthly SIP</span>
              <span className="text-2xl tracking-tight">
                ${sipSchedule.filter(s => s.frequency === 'Monthly').reduce((sum, s) => sum + s.amount, 0).toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Filters & Search */}
        <div className="mb-8 flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-border bg-background focus:outline-none focus:ring-1 focus:ring-foreground"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter size={20} className="text-muted-foreground" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-3 border border-border bg-background focus:outline-none focus:ring-1 focus:ring-foreground"
            >
              <option value="all">All Types</option>
              <option value="buy">Buy</option>
              <option value="sell">Sell</option>
              <option value="dividend">Dividend</option>
              <option value="interest">Interest</option>
              <option value="fee">Fee</option>
            </select>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="border border-border">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="text-left p-6 text-sm tracking-wide text-muted-foreground">DATE & TIME</th>
                  <th className="text-left p-6 text-sm tracking-wide text-muted-foreground">TYPE</th>
                  <th className="text-left p-6 text-sm tracking-wide text-muted-foreground">ASSET</th>
                  <th className="text-right p-6 text-sm tracking-wide text-muted-foreground">SHARES</th>
                  <th className="text-right p-6 text-sm tracking-wide text-muted-foreground">PRICE</th>
                  <th className="text-right p-6 text-sm tracking-wide text-muted-foreground">FEES</th>
                  <th className="text-right p-6 text-sm tracking-wide text-muted-foreground">TOTAL</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((tx) => (
                  <tr key={tx.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                    <td className="p-6">
                      <div className="text-sm">
                        <div className="font-medium">{new Date(tx.date).toLocaleDateString()}</div>
                        <div className="text-muted-foreground">{tx.time}</div>
                      </div>
                    </td>
                    <td className="p-6">
                      <div className="flex items-center space-x-2">
                        {getTypeIcon(tx.type)}
                        <span className="text-sm">{getTypeLabel(tx.type)}</span>
                      </div>
                    </td>
                    <td className="p-6">
                      <div>
                        <div className="font-medium">{tx.symbol}</div>
                        <div className="text-sm text-muted-foreground">{tx.name}</div>
                      </div>
                    </td>
                    <td className="p-6 text-right">{tx.shares > 0 ? tx.shares : '-'}</td>
                    <td className="p-6 text-right text-muted-foreground">
                      {tx.price > 0 ? `$${tx.price.toFixed(2)}` : '-'}
                    </td>
                    <td className="p-6 text-right text-muted-foreground">
                      {tx.fees > 0 ? `$${tx.fees.toFixed(2)}` : '-'}
                    </td>
                    <td className="p-6 text-right">
                      <span className={`font-medium ${
                        ['sell', 'dividend', 'interest'].includes(tx.type) ? 'text-success' :
                        ['buy', 'fee'].includes(tx.type) ? 'text-destructive' : ''
                      }`}>
                        {['sell', 'dividend', 'interest'].includes(tx.type) ? '+' : '-'}
                        ${tx.total.toFixed(2)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
